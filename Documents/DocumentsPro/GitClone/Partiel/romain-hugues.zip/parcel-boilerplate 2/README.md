# Parcel boilerplate

Minimal boilerplate for parcel powered project

## How to use

Clone and cd into the repository and run `npm install`

### Development mode

```npm run dev```

Open `localhost:1234`

### Production mode

```npm run build```

Serve the `dist` folder.
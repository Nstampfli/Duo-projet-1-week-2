import  Data  from "../../data";

for(i = 0; i < Data.length; i++){

}



var liste = document.querySelector('.frameworks__cards')
var newCard = document.createElement('div'); 
newCard.className = "framework__card"; 
var text = document.createTextNode(Data.angular.title);
newCard.appendChild(text); 
var frameworksCard = document.querySelector('.framework__card')
liste.insertBefore(newCard, frameworksCard);
const Data = {
  react: {
    title: 'React',
    icon: 'https://raw.githubusercontent.com/rexxars/react-hexagon/HEAD/logo/react-hexagon.png',
    date: "Créé en 2013", 
    creator: "Développé par Facebook", 
    link: "https://reactjs.org/",
  },
  angular: {
    title: 'Angular',
    icon: 'https://angular.io/assets/images/logos/angularjs/AngularJS-Shield.svg',
    date: "Créé en 2016", 
    creator: "Développé par Google", 
    link: "https://angular.io/",
  },
  vue: {
    title: 'Vue',
    icon: 'https://cdn.freebiesupply.com/logos/large/2x/vue-9-logo-svg-vector.svg',
    date: "Créé en 2014", 
    creator: "Développé par Evan You", 
    link: "https://vuejs.org/",
  },
};


export default Data